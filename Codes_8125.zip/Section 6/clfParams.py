def paramDict():
    param_dict = {
        # Random Forest parameters
        'rf_params': {'n_jobs': -1,
                      'n_estimators': 500,
                      'warm_start': True,
                      #'max_features': 0.2,
                      'max_depth': 6,
                      'min_samples_leaf': 2,
                      'max_features' : 'sqrt',
                      'verbose': 0},

        # Extra Trees Parameters
        'et_params': {'n_jobs': -1,
                      'n_estimators':500,
                      #'max_features': 0.5,
                      'max_depth': 8,
                      'min_samples_leaf': 2,
                      'verbose': 0},

        # AdaBoost parameters
        'ada_params': {'n_estimators': 500,
                       'learning_rate' : 0.75},

        # Gradient Boosting parameters
        'gb_params': {'n_estimators': 500,
                      #'max_features': 0.2,
                      'max_depth': 5,
                      'min_samples_leaf': 2,
                      'verbose': 0},

        # Support Vector Classifier parameters
        'svc_params': {'kernel' : 'linear',
                       'C' : 0.025}
    }

    return param_dict
